<?php 



//no closing tag


require_once '../app/init.php';

$app=new App();



