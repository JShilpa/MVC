	<?php 


Class Home extends Controller
{


	public function index($name='')
	{
		
		$user=$this->model('User');
		$user->$name=$name;
		echo $user->$name;

		$this->view('home/index', array('name'=>$user->$name));


		
	}
	
}








 ?>