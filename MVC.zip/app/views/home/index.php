hello 
<?php echo $data['name']; ?>